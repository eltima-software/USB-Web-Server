<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Received messages");
define("MESSLAN_2", "Delete Message");
define("MESSLAN_3", "Message Deleted.");
define("MESSLAN_4", "Delete All Messages");
define("MESSLAN_5", "Confirm");
define("MESSLAN_6", "All messages deleted.");
define("MESSLAN_7", "No messages.");
define("MESSLAN_8", "Message type");
define("MESSLAN_9", "Reported on");

define("MESSLAN_10", "Submitted by");
define("MESSLAN_11", "opens in new window");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Link");


?>