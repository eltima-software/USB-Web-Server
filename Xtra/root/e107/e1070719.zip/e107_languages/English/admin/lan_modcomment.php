<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderated.");
define("MDCLAN_2", "No comments for this item");
define("MDCLAN_3", "Member");
define("MDCLAN_4", "Guest");
define("MDCLAN_5", "unblock");
define("MDCLAN_6", "block");

define("MDCLAN_8", "Moderate Comments");
define("MDCLAN_9", "Warning! Deleting Parent comments will also delete all replies!");

define("MDCLAN_10", "options");
define("MDCLAN_11", "comment");
define("MDCLAN_12", "comments");
define("MDCLAN_13", "blocked");
define("MDCLAN_14", "lock comments");
define("MDCLAN_15", "open");
define("MDCLAN_16", "locked");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>