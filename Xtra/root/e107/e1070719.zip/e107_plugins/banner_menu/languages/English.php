<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/banner_menu/languages/English.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Advertisement");
define("BANNER_MENU_L2", "Banner menu configuration saved");

//v.617
define("BANNER_MENU_L3", "Caption");
define("BANNER_MENU_L4", "Campaign");
define("BANNER_MENU_L5", "Banner Menu Configuration");
define("BANNER_MENU_L6", "choose campaigns to show in menu");
define("BANNER_MENU_L7", "available campaigns");
define("BANNER_MENU_L8", "selected campaigns");
define("BANNER_MENU_L9", "remove selection");
define("BANNER_MENU_L10", "how should the selected campaigns be shown ?");
define("BANNER_MENU_L11", "choose render type ...");
define("BANNER_MENU_L12", "one campaign in single menu");
define("BANNER_MENU_L13", "all selected campaigns in single menu");
define("BANNER_MENU_L14", "all selected campaigns in separate menus");
define("BANNER_MENU_L15", "how many banners should be shown ?");
define("BANNER_MENU_L16", "this setting will only be used with options 2 and 3.<br />if less banners are present the maximum available amount will be used.");
define("BANNER_MENU_L17", "set amount ...");
define("BANNER_MENU_L18", "Update Menu Settings");

?>