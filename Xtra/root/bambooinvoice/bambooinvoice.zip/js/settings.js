function settingsInit() {
				var my_glider = new Glider('settings_sections', {duration:0.5});
}

addEvent (window, "load", settingsInit);
