<?php  if (!defined("BASEPATH")) exit("No direct script access allowed");

$active_group = "default";
$db["default"]["hostname"] = "localhost";
$db["default"]["username"] = "bamboo";
$db["default"]["password"] = "usbw";
$db["default"]["database"] = "bamboo";
$db["default"]["dbdriver"] = "mysql";
$db["default"]["dbprefix"] = "bamboo_";
$db["default"]["active_r"] = TRUE;
$db["default"]["pconnect"] = FALSE;
$db["default"]["db_debug"] = TRUE;
$db["default"]["cache_on"] = FALSE;
$db["default"]["cachedir"] = "";
$db["default"]["char_set"] = "utf8";
$db["default"]["dbcollat"] = "utf8_general_ci";

?>