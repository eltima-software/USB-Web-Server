<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
* If you are using BambooInvoice in a professionally hosted environment, you probably don't need
* to do anything to this file.  If you are running it from your home server, or have setup
* BambooInvoice on a pre-configured server setup, such as WinLAMP or XXAMP, then you'll likely
* need to uncomment the configuration information below.
*
* Check with your ISP for this information.  It is usually given in the welcome information
* when you sign up for the service, or can likely be retrieved from your email package of choice.
*/

/*
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp1.mailserver.ca';
$config['smtp_user'] = 'username';
$config['smtp_pass'] = 'password';
$config['smtp_port'] = '25';
*/

?>