<?php

/*
DOMpdf had a security issue reported with it.  Since Bamboo does not use the vulnerable file (this one)
I've simply opted to replace it with this blank file.  This way, users who are upgrading from earlier versions will
replace the vulnerable file with this one... and be none-the-wiser.  How sneaky of me!

Reference at http://www.digitaljunkies.ca/dompdf/
*/

?>