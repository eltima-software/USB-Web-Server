<?php
$lang['required'] 		= "El camp %s és obligatori.";
$lang['isset']			= "El camp %s ha de contenir un valor.";
$lang['valid_email']		= "El camp %s ha de contenir una adreça de correu electrònic vàlida.";
$lang['valid_url'] 		= "El camp %s ha de contenir una adreça web vàlida.";
$lang['min_length']		= "El camp %s ha de contenir al menys %s caràcters de llargada.";
$lang['max_length']		= "El camp %s no pot ésser més llarg de %s caràcters.";
$lang['exact_length']		= "El camp %s ha de tenir exactament %s caràcteres de llarg.";
$lang['alpha']			= "El camp %s solsament pot contenir caràcters alfanumèricos.";
$lang['alpha_dash']		= "El camp %s solsament pot contenir caràcters alfanumèricos, guions i guions baixos.";
$lang['numeric']		= "El camp %s només accepta números.";
$lang['matches']		= "El camp %s no és igual al camp %s.";
?>
