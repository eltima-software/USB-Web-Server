<?php
$lang['scaff_view_records']		= 'Veure registres';
$lang['scaff_create_record']		= 'Crear nou registre';
$lang['scaff_add']			= 'Afegir dades';
$lang['scaff_view']			= 'Veure dades';
$lang['scaff_edit']			= 'Editar';
$lang['scaff_delete']			= 'Esborrar';
$lang['scaff_view_all']			= 'Veure-ho tot';
$lang['scaff_yes']			= 'Si';
$lang['scaff_no']			= 'No';
$lang['scaff_no_data']			= 'Encara no existeixen dades per aquesta taula.';
$lang['scaff_del_confirm']		= 'Està segur de voler eliminar la següent fila?:';
?>
