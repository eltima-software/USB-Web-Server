<?php

$lang['profiler_benchmarks']		= 'PUNTS DE REFERÈNCiA';
$lang['profiler_queries']		= 'CONSULTES';
$lang['profiler_post_data']		= 'DADES POST';
$lang['profiler_no_db']			= 'El driver per la base de dades no s\'ha carregat';
$lang['profiler_no_queries']		= 'No s\'han exectutat consultes';
$lang['profiler_no_post']		= 'No existeixen dades del tipus POST';

?>
