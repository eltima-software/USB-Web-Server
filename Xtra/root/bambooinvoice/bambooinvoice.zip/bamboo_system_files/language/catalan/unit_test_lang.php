<?php
$lang['ut_test_name']		= 'Nom de prova';
$lang['ut_test_datatype']	= 'Tipus de dades de prova';
$lang['ut_res_datatype']	= 'Tipus de dades esperades';
$lang['ut_result']			= 'Resultat';
$lang['ut_undefined']		= 'Nom de prova no definit';
$lang['ut_file']			= 'Nom del fitxer';
$lang['ut_line']			= 'Número de línia';
$lang['ut_passed']			= 'Aprovat';
$lang['ut_failed']			= 'Fallit';
$lang['ut_boolean']			= 'Booleà';
$lang['ut_integer']			= 'Enter';
$lang['ut_double']			= 'Float';
$lang['ut_float']			= 'Floag';
$lang['ut_string']			= 'String';
$lang['ut_array']			= 'Array';
$lang['ut_object']			= 'Object';
$lang['ut_resource']		= 'Resource';
$lang['ut_null']			= 'Null';
?>
