<?php

$lang['scaff_view_records']		= 'Visa Poster';
$lang['scaff_create_record']	= 'Skapa Ny Post';
$lang['scaff_add']				= 'Lägg till Data';
$lang['scaff_view']				= 'Visa Data';
$lang['scaff_edit']				= 'Redigera';
$lang['scaff_delete']			= 'Ta bort';
$lang['scaff_view_all']			= 'Visa Alla';
$lang['scaff_yes']				= 'Ja';
$lang['scaff_no']				= 'Nej';
$lang['scaff_no_data']			= 'Tabellen är tom.';
$lang['scaff_del_confirm']		= 'Vill du verkligen ta bort följande rad:';



/* End of file unit_test_lang.php */
/* Location: ./system/language/swedish/unit_test_lang.php */