<?php

$lang['profiler_benchmarks']	= 'BENCHMARKS';
$lang['profiler_queries']		= 'INTEROGARI';
$lang['profiler_post_data']		= 'POST DATA';
$lang['profiler_no_db']			= 'Baza de date nu este interogata';
$lang['profiler_no_queries']	= 'Nu exista interogari';
$lang['profiler_no_post']		= 'Nu exista date POST';

?>