<?php

$lang['scaff_view_records']		= 'Vizualizeaza Inregistrarile';
$lang['scaff_create_record']	= 'Creeaza Inregistrare Noua';
$lang['scaff_add']				= 'Adauga Informatia';
$lang['scaff_view']				= 'Vizualizeaza Informatia';
$lang['scaff_edit']				= 'Editeaza';
$lang['scaff_delete']			= 'Sterge';
$lang['scaff_view_all']			= 'Vizualizeaza Totul';
$lang['scaff_yes']				= 'Da';
$lang['scaff_no']				= 'Nu';
$lang['scaff_no_data']			= 'Nu exista informatie pentru acest tabel inca.';
$lang['scaff_del_confirm']		= 'Esti sigur ca vrei sa stergi urmatorul camp:';

?>