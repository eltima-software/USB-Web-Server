<?php

$lang['profiler_benchmarks']    = 'BENCHMARKS';
$lang['profiler_queries']    = 'QUERIES';
$lang['profiler_post_data']    = 'POST DATA';
$lang['profiler_no_db']        = 'Database driver is momenteel niet geladen';
$lang['profiler_no_queries']    = 'Er zijn geen queries uitgevoerd';
$lang['profiler_no_post']    = 'Er is geen POST data';

?>