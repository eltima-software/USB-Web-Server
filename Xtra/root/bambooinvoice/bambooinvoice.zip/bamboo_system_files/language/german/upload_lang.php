<?php

$lang['upload_userfile_not_set'] = "Konnte die post Variable namens userfile nicht finden.";
$lang['upload_file_exceeds_limit'] = "Die Datei berschreitet die in Ihren PHP Einstellungen vorgegebene Grsse.";
$lang['upload_file_partial'] = "Die Datei wurde nur teilweise hochgeladen";
$lang['upload_no_file_selected'] = "Sie haben keine Datei zum Hochladen ausgewhlt";
$lang['upload_invalid_filetype'] = "Der Typ der gewhlten Datei ist nicht erlaubt";
$lang['upload_invalid_filesize'] = "Die Datei, die Sie hochladen wollen, ist grsser als erlaubt";
$lang['upload_invalid_dimensions'] = "Die Bildbreite oder -hhe Ihres hochzuladenden Bildes ist grsser als erlaubt";
$lang['upload_destination_error'] = "Ein Problem entstand beim Versuch Ihr Bild endgltig zu speichern.";
$lang['upload_no_filepath'] = "Die Upload-Pfadangabe scheint nicht zu stimmen.";
$lang['upload_no_file_types'] = "Sie haben keinen der erlaubten Bildtypen ausgewhlt.";
$lang['upload_bad_filename'] = "Eine Datei dieses Namens existiert bereits.";
$lang['upload_not_writable'] = "Das Zielverzeichnis kann anscheinend nicht beschrieben werden.";

?>