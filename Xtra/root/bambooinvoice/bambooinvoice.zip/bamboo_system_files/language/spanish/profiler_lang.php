<?php

$lang['profiler_benchmarks']	= 'BENCHMARKS';
$lang['profiler_queries']		= 'CONSULTAS';
$lang['profiler_post_data']		= 'DATOS POST';
$lang['profiler_no_db']			= 'El driver para la base de datos no ha sido cargado';
$lang['profiler_no_queries']	= 'No se han ejecutado consultas';
$lang['profiler_no_post']		= 'No existen datos de tipo POST';

?>
