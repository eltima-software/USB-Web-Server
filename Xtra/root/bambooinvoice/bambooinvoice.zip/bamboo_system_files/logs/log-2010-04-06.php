<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-04-06 22:10:46 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) E:\Projecten\Usbwebserver\V8\Xtra\root\bambooinvoice\bamboo_system_files\database\drivers\mysql\mysql_driver.php 70
ERROR - 2010-04-06 22:10:46 --> Unable to connect to the database
ERROR - 2010-04-06 22:23:30 --> Severity: Notice  --> Array to string conversion E:\Projecten\Usbwebserver\V8\Xtra\root\bambooinvoice\bamboo_system_files\application\config\config.php 18
