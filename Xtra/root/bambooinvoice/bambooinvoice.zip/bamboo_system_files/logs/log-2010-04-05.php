<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-04-05 21:24:13 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'root'@'localhost' (using password: YES) E:\Projecten\Usbwebserver\V8\Xtra\root\bambooinvoice\bamboo_system_files\database\drivers\mysql\mysql_driver.php 70
ERROR - 2010-04-05 21:24:13 --> Unable to connect to the database
