<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-10-30 19:36:26 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Users/derekallard/Sites/bambooinvoice/bamboo_system_files/application/models/utilities_model.php 12
ERROR - 2009-10-30 19:36:26 --> Severity: Warning  --> fsockopen() [<a href='function.fsockopen'>function.fsockopen</a>]: unable to connect to bambooinvoice.org:80 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Users/derekallard/Sites/bambooinvoice/bamboo_system_files/application/models/utilities_model.php 12
